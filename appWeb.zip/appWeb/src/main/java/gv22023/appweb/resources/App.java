
package gv22023.appweb.resources;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
 

/**
 *
 * @author Alejandra
 */
@ApplicationPath("/api")
public class App extends Application{

   
    
}
