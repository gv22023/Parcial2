
package gv22023.appweb.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "inscripcion")
public class Inscripcion implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @SequenceGenerator(name = "inscripcion_id_seq", sequenceName = "inscripcion_id_seq", allocationSize = 1)
    @Column(name = "id")
    private Long id;
    @Column(name = "id_alumno")
    private String id_alumno;
    @Column(name = "id_materia")
    private String id_materia;
    @Column(name = "anio")
    private String anio;
    @Column(name = "ciclo")
    private String ciclo;
    @Column(name = "fecha_inscripcion")
    private String fecha_inscripcion;
    
    
}
